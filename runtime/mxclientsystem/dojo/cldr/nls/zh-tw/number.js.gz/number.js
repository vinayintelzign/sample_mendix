/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/zh-tw/number",{"decimalFormat-long":"000兆","nan":"非數值","$locale":"zh-hant-tw","decimalFormat-short":"000兆","currencyFormat-short":"¤000兆"});
