/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-au/currency",{"CHF_symbol":"CHF","JPY_symbol":"JPY","HKD_symbol":"HKD","USD_symbol":"USD","CAD_symbol":"CAD","EUR_symbol":"EUR","CNY_symbol":"CNY","GBP_symbol":"GBP","AUD_symbol":"$"});
