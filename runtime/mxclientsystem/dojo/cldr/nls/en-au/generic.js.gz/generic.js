/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/en-au/generic",{"field-hour-narrow":"h","field-month-short":"mo.","dateFormatItem-yMEd":"E, dd/MM/y","field-weekdayOfMonth-short":"wkday of mo.","field-month-narrow":"mo.","field-hour-short":"h","dateFormatItem-yMd":"dd/MM/y","field-weekOfMonth-short":"wk of mo.","field-second-narrow":"sec.","field-minute-short":"min.","field-minute-narrow":"min.","field-second-short":"sec."});
