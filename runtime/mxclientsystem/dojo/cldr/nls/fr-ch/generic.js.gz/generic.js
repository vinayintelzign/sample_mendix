/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/fr-ch/generic",{"dateFormatItem-yMEd":"E, dd.MM.y GGGGG","dateFormatItem-yMd":"dd.MM.y GGGGG","dateFormat-short":"dd.MM.y GGGGG","dateFormatItem-MMdd":"dd.MM","dateFormatItem-MEd":"E, dd.MM.","dateFormatItem-yM":"MM.y GGGGG","dateFormat-full":"EEEE, d MMMM y G","dateFormatItem-Md":"dd.MM."});
