/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sr/currency",{"HKD_displayName":"Хонгконшки долар","CNY_displayName":"Кинески јуан","JPY_displayName":"Јапански јен","JPY_symbol":"¥","USD_displayName":"Амерички долар","CAD_symbol":"CA$","GBP_displayName":"Британска фунта","CHF_displayName":"Швајцарски франак","CNY_symbol":"CN¥","EUR_displayName":"Евро","GBP_symbol":"£","CAD_displayName":"Канадски долар","USD_symbol":"US$","EUR_symbol":"€","AUD_displayName":"Аустралијски долар","CHF_symbol":"CHF","HKD_symbol":"HK$","AUD_symbol":"AUD"});
