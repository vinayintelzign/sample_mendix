/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/nl/currency",{"HKD_displayName":"Hongkongse dollar","CNY_displayName":"Chinese yuan","JPY_displayName":"Japanse yen","JPY_symbol":"JP¥","USD_displayName":"Amerikaanse dollar","CAD_symbol":"C$","GBP_displayName":"Brits pond","CHF_displayName":"Zwitserse frank","CNY_symbol":"CN¥","EUR_displayName":"Euro","GBP_symbol":"£","CAD_displayName":"Canadese dollar","USD_symbol":"US$","EUR_symbol":"€","AUD_displayName":"Australische dollar","CHF_symbol":"CHF","HKD_symbol":"HK$","AUD_symbol":"AU$"});
