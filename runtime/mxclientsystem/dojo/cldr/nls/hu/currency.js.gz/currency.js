/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/hu/currency",{"HKD_displayName":"hongkongi dollár","CNY_displayName":"kínai jüan","JPY_displayName":"japán jen","JPY_symbol":"¥","USD_displayName":"USA-dollár","CAD_symbol":"CAD","GBP_displayName":"angol font","CHF_displayName":"svájci frank","CNY_symbol":"CNY","EUR_displayName":"euró","GBP_symbol":"GBP","CAD_displayName":"kanadai dollár","USD_symbol":"USD","EUR_symbol":"EUR","AUD_displayName":"ausztrál dollár","CHF_symbol":"CHF","HKD_symbol":"HKD","AUD_symbol":"AUD"});
