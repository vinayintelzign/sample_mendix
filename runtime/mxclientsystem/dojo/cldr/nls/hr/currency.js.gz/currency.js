/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/hr/currency",{"HKD_displayName":"hongkonški dolar","CNY_displayName":"kineski yuan","JPY_displayName":"japanski jen","JPY_symbol":"JPY","USD_displayName":"američki dolar","CAD_symbol":"CAD","GBP_displayName":"britanska funta","CHF_displayName":"švicarski franak","CNY_symbol":"CNY","EUR_displayName":"euro","GBP_symbol":"GBP","CAD_displayName":"kanadski dolar","USD_symbol":"USD","EUR_symbol":"EUR","AUD_displayName":"australski dolar","CHF_symbol":"CHF","HKD_symbol":"HKD","AUD_symbol":"AUD"});
