/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/ko/currency",{"HKD_displayName":"홍콩 달러","CNY_displayName":"중국 위안화","JPY_displayName":"일본 엔화","JPY_symbol":"JP¥","USD_displayName":"미국 달러","CAD_symbol":"CA$","GBP_displayName":"영국 파운드","CHF_displayName":"스위스 프랑","CNY_symbol":"CN¥","EUR_displayName":"유로","GBP_symbol":"£","CAD_displayName":"캐나다 달러","USD_symbol":"US$","EUR_symbol":"€","AUD_displayName":"호주 달러","CHF_symbol":"CHF","HKD_symbol":"HK$","AUD_symbol":"AU$"});
