/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/fi/currency",{"HKD_displayName":"Hongkongin dollari","CNY_displayName":"Kiinan juan","JPY_displayName":"Japanin jeni","JPY_symbol":"¥","USD_displayName":"Yhdysvaltain dollari","CAD_symbol":"CAD","GBP_displayName":"Englannin punta","CHF_displayName":"Sveitsin frangi","CNY_symbol":"CNY","EUR_displayName":"euro","GBP_symbol":"£","CAD_displayName":"Kanadan dollari","USD_symbol":"$","EUR_symbol":"€","AUD_displayName":"Australian dollari","CHF_symbol":"CHF","HKD_symbol":"HKD","AUD_symbol":"AUD"});
