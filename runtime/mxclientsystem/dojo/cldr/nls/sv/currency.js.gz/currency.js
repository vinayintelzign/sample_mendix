/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/sv/currency",{"HKD_displayName":"Hongkongdollar","CNY_displayName":"kinesisk yuan","JPY_displayName":"japansk yen","JPY_symbol":"JPY","USD_displayName":"amerikansk dollar","CAD_symbol":"CA$","GBP_displayName":"brittiskt pund","CHF_displayName":"schweizisk franc","CNY_symbol":"CNY","EUR_displayName":"euro","GBP_symbol":"GBP","CAD_displayName":"kanadensisk dollar","USD_symbol":"US$","EUR_symbol":"€","AUD_displayName":"australisk dollar","CHF_symbol":"CHF","HKD_symbol":"HKD","AUD_symbol":"AUD"});
