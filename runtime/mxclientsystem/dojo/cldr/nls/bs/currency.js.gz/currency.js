/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/bs/currency",{"HKD_displayName":"Honkonški dolar","CNY_displayName":"Kineski juan","JPY_displayName":"Japanski jen","JPY_symbol":"¥","USD_displayName":"Američki dolar","CAD_symbol":"CAD","GBP_displayName":"Britanska funta","CHF_displayName":"Švicarski franak","CNY_symbol":"CNY","EUR_displayName":"Euro","GBP_symbol":"GBP","CAD_displayName":"Kanadski dolar","USD_symbol":"USD","EUR_symbol":"€","AUD_displayName":"Australijski dolar","CHF_symbol":"CHF","HKD_symbol":"HKD","AUD_symbol":"AUD"});
