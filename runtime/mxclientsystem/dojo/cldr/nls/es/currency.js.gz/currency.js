/*
	Copyright (c) 2004-2016, The JS Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/

//>>built
define("dojo/cldr/nls/es/currency",{"HKD_displayName":"dólar hongkonés","CNY_displayName":"yuan","JPY_displayName":"yen","JPY_symbol":"JPY","USD_displayName":"dólar estadounidense","CAD_symbol":"CAD","GBP_displayName":"libra esterlina","CHF_displayName":"franco suizo","CNY_symbol":"CNY","EUR_displayName":"euro","GBP_symbol":"GBP","CAD_displayName":"dólar canadiense","USD_symbol":"US$","EUR_symbol":"€","AUD_displayName":"dólar australiano","CHF_symbol":"CHF","HKD_symbol":"HKD","AUD_symbol":"AUD"});
