//>>built
define("dijit/form/nls/es/Textarea",({iframeEditTitle:"área de edición",iframeFocusTitle:"marco del área de edición"}));
