//>>built
define("dijit/form/nls/es/ComboBox",({previousMessage:"Opciones anteriores",nextMessage:"Más opciones"}));
