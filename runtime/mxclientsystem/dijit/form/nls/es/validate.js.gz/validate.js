//>>built
define("dijit/form/nls/es/validate",({invalidMessage:"El valor especificado no es válido.",missingMessage:"Este valor es necesario.",rangeMessage:"Este valor está fuera del intervalo."}));
